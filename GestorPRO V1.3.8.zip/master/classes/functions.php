<?php
$urlapi = "link da sua api com https://";
$apikey = "sua api key aqui";